import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import Constants from 'expo-constants';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';

// You can import from local files
import { Principal } from './paginas/Tab/Home';

import { NavigationContainer } from '@react-navigation/native';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';

// App.js
// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

///===============================

function Feed({ navigation }) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ color: 'black' }}>
        Pagina Inicial Dentro do Feed apps.js !
      </Text>
      <Principal />
    </View>
  );
}

function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props}>
      <DrawerItemList {...props} />
    </DrawerContentScrollView>
  );
}

const Drawer = createDrawerNavigator();

function MyDrawer() {
  return (
    <Drawer.Navigator
      screenOptions={{
        //headerStyle: { backgroundColor: '#fff' },
        headerTintColor: '#black',
      }}
      useLegacyImplementation
      drawerContent={(props) => <CustomDrawerContent {...props} />}>
      <Drawer.Screen
        name="Feed App.js"
        component={Feed}
        options={{
          title: 'Home',
          drawerIcon: ({ focused, size }) => (
            <Ionicons
              // name="ios-add-circle"
              name="ios-people"
              size={size}
              color={focused ? '#7cc' : '#ccc'}
            />
          ),

          headerRight: () => (
            <MaterialIcons
              name="person"
              size={24}
              onPress={() => navigation.toggleDrawer()}
              style={{ marginLeft: 10 }}
            />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}
////==============================
export default function App() {
  return (
    <View style={styles.container}>
      <NavigationContainer>
        <MyDrawer />
      </NavigationContainer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#6489DE', // cor boa #ecf0f1
    padding: 0, // borda
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
