import * as React from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { Icon } from 'react-native-elements';
//Home.js
import { createDrawerNavigator } from '@react-navigation/drawer';


// centro da tela
function Inicio() {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'spance-evenly',
        alignItems: 'center',
        backgroundColor: 'blue',
      }}>
     
    </View>
  );
}

// centro da tela
function Profile() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Profile!</Text>
      <Icon name="login" />
    </View>
  );
}

// centro da tela
function Notifications() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Notifications!</Text>
      <Icon name="home" />
      <Icon name="bluetooth" />

      <Icon name="sc-telegram" type="evilicon" color="red" width="70px" />

      <Icon
        reverse
        name="ios-american-football"
        type="ionicon"
        color="#517fa4"
      />

      <Icon
        raised
        name="back"
        type="font-awesome"
        color="#f50"
        onPress={() => console.log('hello')}
      />
    </View>
  );
}

const Tab = createBottomTabNavigator();

/*
const Tab_cima = createMaterialTopTabNavigator();


function Usuario() {
  return (
    <Tab_cima.Navigator>
      
      <Tab_cima.Screen
        
      />
    </Tab_cima.Navigator>
  );
}
*/

function MyTabs() {
  return (
    <Tab.Navigator
      initialRouteName="Feed"
      screenOptions={{
        tabBarActiveTintColor: 'black', //  cor do icone quando clica
      }}>
      <Tab.Screen
        name="Home Basr"
        component={Inicio}
        options={{
          headerShown: false,
          tabBarLabel: 'Inicio',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="home" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Carrinho"
        component={Notifications}
        options={{
          headerShown: false,
          tabBarLabel: 'Carrinho',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="cart" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Profilee"
        component={Profile}
        options={{
          headerShown: false,
          tabBarLabel: 'Promoção',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="fire" color={color} size={size} />
          ),
          headerTitle: 'Tela Inicial',
          headerStyle: {
            backgroundColor: 'pink',
          },
          // headerTintColor: 'yellow',
          headerTitleAlign: 'leaf',
        }}
      />
    </Tab.Navigator>
  );
}


function Principal(){
  return (
    <View style={{ flex: 1 ,width :380 }}>
    <NavigationContainer independent={true}>
   
     <Text>Fora da Navegação Home.js </Text>
      <MyTabs />
    </NavigationContainer>
    </View>
  );
}



export {Principal ,MyTabs}