import * as React from 'react';
import { Text, View } from 'react-native';

// centro da tela

function TeladePerfilUsuario() {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'spance-evenly',
        alignItems: 'center',
        backgroundColor: 'red',
      }}>
     
    </View>
  );
}
export{TeladePerfilUsuario}


